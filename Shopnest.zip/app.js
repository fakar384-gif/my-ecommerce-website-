// ==========================================
// 0. Firebase Setup & Initialization
// ==========================================
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { 
    getAuth, 
    createUserWithEmailAndPassword, 
    signInWithEmailAndPassword,
    onAuthStateChanged, 
    signOut 
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

// 🟢 Firestore Database 
import { 
    getFirestore, 
    collection, 
    addDoc, 
    serverTimestamp,
    query,
    where,
    getDocs,
    onSnapshot,
    orderBy,
    doc,
    deleteDoc,
    updateDoc
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCm_Q4TXyaoV46HkmnmwFmR71UccOKIxmc",
  authDomain: "shopnest-1f3bc.firebaseapp.com",
  projectId: "shopnest-1f3bc",
  storageBucket: "shopnest-1f3bc.firebasestorage.app",
  messagingSenderId: "167119449832",
  appId: "1:167119449832:web:db9a71363bc7de5bf0635d"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app); 


// ==========================================
// 1. Theme Toggle System (Dark / Light Mode)
// ==========================================
const themeToggleBtn = document.getElementById('themeToggle');
const htmlElement = document.documentElement;

const savedTheme = localStorage.getItem('shopnest_theme');
if (savedTheme) {
    htmlElement.setAttribute('data-theme', savedTheme);
    updateThemeIcon(savedTheme);
}

if(themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
        const currentTheme = htmlElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        htmlElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('shopnest_theme', newTheme);
        updateThemeIcon(newTheme);
    });
}

function updateThemeIcon(theme) {
    if(themeToggleBtn) {
        if (theme === 'dark') {
            themeToggleBtn.textContent = '☀️';
        } else {
            themeToggleBtn.textContent = '🌙';
        }
    }
}


// ==========================================
// 2. Flash Sale Countdown Timer
// ==========================================
const countdownElement = document.getElementById('countdown');

if(countdownElement) {
    let totalSeconds = (2 * 3600) + (45 * 60) + 30; 

    const timerInterval = setInterval(() => {
        if (totalSeconds <= 0) {
            clearInterval(timerInterval);
            countdownElement.textContent = "Sale Ended!";
            return;
        }
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;

        const formattedHours = String(hours).padStart(2, '0');
        const formattedMinutes = String(minutes).padStart(2, '0');
        const formattedSeconds = String(seconds).padStart(2, '0');

        countdownElement.textContent = `${formattedHours}:${formattedMinutes}:${formattedSeconds}`;
        totalSeconds--;
    }, 1000);
}


// ==========================================
// 3. Toast Notification System
// ==========================================
const toastElement = document.createElement('div');
toastElement.className = 'toast';
document.body.appendChild(toastElement);

function showToast(message) {
    toastElement.textContent = message;
    toastElement.classList.add('show');
    setTimeout(() => {
        toastElement.classList.remove('show');
    }, 3000);
}


// ==========================================
// 4. Advanced Shopping Cart Logic
// ==========================================
let cart = JSON.parse(localStorage.getItem('shopnest_cart')) || [];
const cartCountElement = document.getElementById('cart-count');
const cartIcon = document.querySelector('.cart-icon');
const cartDrawer = document.getElementById('cartDrawer');
const cartOverlay = document.getElementById('cartOverlay');
const closeCartBtn = document.getElementById('closeCartBtn');
const cartItemsContainer = document.getElementById('cartItemsContainer');
const cartTotalAmount = document.getElementById('cartTotalAmount');

if(cartCountElement) updateCartUI();

if(cartIcon && cartDrawer && cartOverlay) {
    cartIcon.addEventListener('click', () => {
        cartDrawer.classList.add('open');
        cartOverlay.classList.add('active');
    });
}

function closeCart() {
    if(cartDrawer && cartOverlay) {
        cartDrawer.classList.remove('open');
        cartOverlay.classList.remove('active');
    }
}

if(closeCartBtn) closeCartBtn.addEventListener('click', closeCart);
if(cartOverlay) cartOverlay.addEventListener('click', closeCart);

const addToCartButtons = document.querySelectorAll('.add-to-cart-btn');
addToCartButtons.forEach(button => {
    button.addEventListener('click', (event) => {
        const productCard = event.target.closest('.product-card');
        const productTitle = productCard.querySelector('.product-title').innerText;
        const productPriceStr = productCard.querySelector('.current-price').innerText;
        const priceValue = parseFloat(productPriceStr.replace('₹', ''));

        const existingProduct = cart.find(item => item.name === productTitle);

        if (existingProduct) {
            existingProduct.quantity += 1;
        } else {
            cart.push({ name: productTitle, price: priceValue, quantity: 1 });
        }
        
        localStorage.setItem('shopnest_cart', JSON.stringify(cart));
        updateCartUI();
        showToast(`${productTitle} added to cart! 🛒`);
    });
});

function updateCartUI() {
    if(!cartCountElement) return;

    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCountElement.textContent = totalItems;
    
    cartCountElement.style.transform = 'scale(1.5)';
    setTimeout(() => cartCountElement.style.transform = 'scale(1)', 200);

    if(cartItemsContainer) {
        cartItemsContainer.innerHTML = ''; 
        let totalPrice = 0;

        if (cart.length === 0) {
            cartItemsContainer.innerHTML = '<p style="text-align:center; color:gray;">Your cart is empty.</p>';
        } else {
            cart.forEach((item, index) => {
                totalPrice += item.price * item.quantity;
                cartItemsContainer.innerHTML += `
                    <div class="cart-item">
                        <div class="cart-item-info">
                            <h4>${item.name}</h4>
                            <p>₹${item.price.toFixed(2)} x ${item.quantity}</p>
                        </div>
                        <button class="remove-item-btn" onclick="removeFromCart(${index})">Remove</button>
                    </div>
                `;
            });
        }
        if(cartTotalAmount) cartTotalAmount.textContent = `₹${totalPrice.toFixed(2)}`;
    }
}

window.removeFromCart = function(index) {
    cart.splice(index, 1);
    localStorage.setItem('shopnest_cart', JSON.stringify(cart));
    updateCartUI();
};


// ==========================================
// 5. Category Filtering System
// ==========================================
const categoryBoxes = document.querySelectorAll('.category-box');
const productCards = document.querySelectorAll('.product-card');

categoryBoxes.forEach(box => {
    box.addEventListener('click', () => {
        categoryBoxes.forEach(b => b.classList.remove('active'));
        box.classList.add('active');

        const selectedCategory = box.getAttribute('data-category').toLowerCase();

        productCards.forEach(card => {
            const cardCategory = card.querySelector('.category').innerText.toLowerCase();

            if (selectedCategory === 'all' || cardCategory === selectedCategory) {
                card.style.display = 'block';
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'scale(1)';
                }, 50);
            } else {
                card.style.opacity = '0';
                card.style.transform = 'scale(0.8)';
                setTimeout(() => {
                    card.style.display = 'none';
                }, 300); 
            }
        });
    });
});


// ==========================================
// 6. Product Details Page Logic
// ==========================================
const mainImage = document.getElementById('mainProductImage');
const thumbnails = document.querySelectorAll('.thumbnail');

if (mainImage && thumbnails) {
    thumbnails.forEach(thumb => {
        thumb.addEventListener('click', function() {
            mainImage.src = this.src;
            thumbnails.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

const btnDecrease = document.getElementById('decreaseQty');
const btnIncrease = document.getElementById('increaseQty');
const qtyInput = document.getElementById('productQty');

if (btnDecrease && btnIncrease && qtyInput) {
    btnDecrease.addEventListener('click', () => {
        if (qtyInput.value > 1) {
            qtyInput.value = parseInt(qtyInput.value) - 1;
        }
    });

    btnIncrease.addEventListener('click', () => {
        qtyInput.value = parseInt(qtyInput.value) + 1;
    });
}

const detailAddToCartBtn = document.getElementById('detailAddToCart');
if (detailAddToCartBtn) {
    detailAddToCartBtn.addEventListener('click', () => {
        const productTitle = document.querySelector('.product-title-large').innerText;
        const productPriceStr = document.getElementById('productPrice').innerText;
        const priceValue = parseFloat(productPriceStr.replace('₹', ''));
        const quantity = parseInt(qtyInput.value);

        const existingProduct = cart.find(item => item.name === productTitle);

        if (existingProduct) {
            existingProduct.quantity += quantity; 
        } else {
            cart.push({ name: productTitle, price: priceValue, quantity: quantity });
        }
        
        localStorage.setItem('shopnest_cart', JSON.stringify(cart));
        updateCartUI();
        showToast(`${quantity} x ${productTitle} added to cart! 🛒`);
    });
}


// ==========================================
// 7. Checkout Page Logic
// ==========================================
const checkoutItemsContainer = document.getElementById('checkoutItemsContainer');
const checkoutSubtotal = document.getElementById('checkoutSubtotal');
const checkoutTax = document.getElementById('checkoutTax');
const checkoutTotal = document.getElementById('checkoutTotal');
const checkoutForm = document.getElementById('checkoutForm');

if (checkoutItemsContainer) {
    let subtotal = 0;
    const shippingFee = 50.00; // Changed to INR

    if (cart.length === 0) {
        checkoutItemsContainer.innerHTML = '<p>Your cart is empty.</p>';
        const placeOrderBtn = document.getElementById('placeOrderBtn');
        if(placeOrderBtn) placeOrderBtn.disabled = true; 
    } else {
        cart.forEach(item => {
            const itemTotal = item.price * item.quantity;
            subtotal += itemTotal;
            
            checkoutItemsContainer.innerHTML += `
                <div class="checkout-item">
                    <div>
                        <h4>${item.name}</h4>
                        <p>Qty: ${item.quantity}</p>
                    </div>
                    <div>
                        <strong>₹${itemTotal.toFixed(2)}</strong>
                    </div>
                </div>
            `;
        });
    }

    const taxAmount = subtotal * 0.05; 
    const grandTotal = subtotal + taxAmount + (subtotal > 0 ? shippingFee : 0);

    if(checkoutSubtotal) checkoutSubtotal.textContent = `₹${subtotal.toFixed(2)}`;
    if(checkoutTax) checkoutTax.textContent = `₹${taxAmount.toFixed(2)}`;
    if(checkoutTotal) checkoutTotal.textContent = `₹${grandTotal.toFixed(2)}`;

    // Place Order Submission (Firestore Database Update)
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', async (e) => {
            e.preventDefault(); 
            
            const submitBtn = document.getElementById('placeOrderBtn');
            submitBtn.disabled = true;
            submitBtn.textContent = 'Processing Order...';

            try {
                const firstName = checkoutForm.querySelector('input[placeholder="Enter your first name"]').value;
                const email = checkoutForm.querySelector('input[type="email"]').value;
                const address = checkoutForm.querySelector('input[placeholder="123 Main Street, Appt 4B"]').value;
                const paymentMethod = checkoutForm.querySelector('input[name="payment"]:checked').value;

                const docRef = await addDoc(collection(db, "orders"), {
                    customerName: firstName,
                    customerEmail: email,
                    shippingAddress: address,
                    paymentMethod: paymentMethod,
                    orderItems: cart, 
                    totalAmount: grandTotal, 
                    orderDate: serverTimestamp(), 
                    status: "Pending" 
                });

                alert('🎉 Order Placed Successfully!\nYour Order ID is: ' + docRef.id);
                
                cart = [];
                localStorage.setItem('shopnest_cart', JSON.stringify(cart));
                window.location.href = 'index.html';
                
            } catch (error) {
                console.error("Error adding document: ", error);
                alert('❌ Error placing order. Please try again.');
                submitBtn.disabled = false;
                submitBtn.textContent = 'Place Order';
            }
        });
    }
}


// ==========================================
// 8. Real Firebase Login & Registration
// ==========================================
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const showRegisterBtn = document.getElementById('showRegister');
const showLoginBtn = document.getElementById('showLogin');

if (loginForm && registerForm) {
    
    showRegisterBtn.addEventListener('click', () => {
        loginForm.classList.remove('active');
        registerForm.classList.add('active');
    });

    showLoginBtn.addEventListener('click', () => {
        registerForm.classList.remove('active');
        loginForm.classList.add('active');
    });

    registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = registerForm.querySelector('input[type="email"]').value;
        const password = registerForm.querySelector('input[type="password"]').value;

        createUserWithEmailAndPassword(auth, email, password)
            .then((userCredential) => {
                alert('🎉 Account Created Successfully! Please login.');
                registerForm.reset();
                registerForm.classList.remove('active');
                loginForm.classList.add('active');
            })
            .catch((error) => {
                alert(`❌ Error: ${error.message}`);
            });
    });

    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = loginForm.querySelector('input[type="email"]').value;
        const password = loginForm.querySelector('input[type="password"]').value;

        signInWithEmailAndPassword(auth, email, password)
            .then((userCredential) => {
                alert('✅ Login Successful! Welcome back.');
                window.location.href = 'index.html';
            })
            .catch((error) => {
                alert(`❌ Invalid Email or Password!`);
            });
    });
}


// ==========================================
// 9. Auth State Observer & Profile Navigation
// ==========================================
const authLink = document.getElementById('authLink');

onAuthStateChanged(auth, (user) => {
    if (authLink) {
        if (user) {
            authLink.innerHTML = '👤 My Profile';
            authLink.href = 'profile.html'; 
        } else {
            authLink.innerHTML = '👤 Login';
            authLink.href = 'login.html'; 
        }
    }

    // ==========================================
    // 10. Profile Page Logic (Order History Fetch)
    // ==========================================
    const profileName = document.getElementById('profileName');
    const profileEmail = document.getElementById('profileEmail');
    const orderListContainer = document.getElementById('orderListContainer');
    const logoutBtn = document.getElementById('logoutBtn');

    if (profileName && profileEmail && orderListContainer) {
        if (user) {
            profileEmail.textContent = user.email;
            profileName.textContent = "Awesome Shopper"; 

            fetchUserOrders(user.email);

            if (logoutBtn) {
                logoutBtn.addEventListener('click', () => {
                    signOut(auth).then(() => {
                        window.location.href = 'index.html'; 
                    });
                });
            }
        } else {
            window.location.href = 'login.html';
        }
    }
});

async function fetchUserOrders(userEmail) {
    const orderListContainer = document.getElementById('orderListContainer');
    
    try {
        const q = query(collection(db, "orders"), where("customerEmail", "==", userEmail));
        const querySnapshot = await getDocs(q);
        
        orderListContainer.innerHTML = ''; 

        if (querySnapshot.empty) {
            orderListContainer.innerHTML = '<p>You have no orders yet. Start shopping!</p>';
            return;
        }

        querySnapshot.forEach((doc) => {
            const orderData = doc.data();
            
            let itemsHtml = '';
            orderData.orderItems.forEach(item => {
                itemsHtml += `<p>✔️ ${item.name} (Qty: ${item.quantity}) - ₹${(item.price * item.quantity).toFixed(2)}</p>`;
            });

            const dateStr = orderData.orderDate ? orderData.orderDate.toDate().toLocaleDateString() : 'Just Now';
            
            orderListContainer.innerHTML += `
                <div class="order-card">
                    <div class="order-header">
                        <div>
                            <strong>Order ID:</strong> #${doc.id.slice(0,8).toUpperCase()}<br>
                            <span class="text-muted">Date: ${dateStr}</span>
                        </div>
                        <div>
                            <span class="order-status">${orderData.status}</span>
                        </div>
                    </div>
                    <div class="order-items-list">
                        ${itemsHtml}
                    </div>
                    <div style="margin-top: 1rem; border-top: 1px solid #ccc; padding-top: 0.5rem;">
                        <strong>Total Paid: ₹${orderData.totalAmount.toFixed(2)}</strong> 
                        <span class="text-muted">(${orderData.paymentMethod.toUpperCase()})</span>
                    </div>
                </div>
            `;
        });
    } catch (error) {
        console.log("Error fetching orders:", error);
        orderListContainer.innerHTML = '<p style="color:red;">Error loading orders.</p>';
    }
}

// ==========================================
// 11. Admin Panel - Upload, Edit & Delete Product
// ==========================================
const adminProductForm = document.getElementById('adminProductForm');
const adminProductList = document.getElementById('adminProductList');
let editingProductId = null; // এডিট করার সময় আইডি মনে রাখার জন্য

// ১. প্রোডাক্ট আপলোড বা আপডেট করার লজিক
if (adminProductForm) {
    adminProductForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const uploadBtn = document.getElementById('uploadBtn');
        uploadBtn.disabled = true;
        uploadBtn.textContent = 'Processing... ⏳';

        try {
            // ফর্ম থেকে ডাটা নেওয়া
            const title = document.getElementById('pTitle').value;
            const category = document.getElementById('pCategory').value;
            const price = parseFloat(document.getElementById('pPrice').value);
            const originalPrice = parseFloat(document.getElementById('pOriginalPrice').value); // New Field Added
            const imageUrl = document.getElementById('pImage').value;
            const affiliateLink = document.getElementById('pAffiliateLink').value;

            if (editingProductId) {
                // ✏️ প্রোডাক্ট এডিট (Update) করা হচ্ছে
                const productRef = doc(db, "products", editingProductId);
                await updateDoc(productRef, {
                    title: title,
                    category: category,
                    price: price,
                    originalPrice: originalPrice, // New Field Added
                    image: imageUrl,
                    affiliateLink: affiliateLink
                });
                alert('✅ Product Updated Successfully!');
                editingProductId = null;
                const formTitle = document.getElementById('formTitle');
                if (formTitle) formTitle.innerHTML = '⚙️ Upload New Product';
                uploadBtn.textContent = '🚀 Upload Product';
            } else {
                // 🚀 নতুন প্রোডাক্ট আপলোড করা হচ্ছে
                await addDoc(collection(db, "products"), {
                    title: title,
                    category: category,
                    price: price,
                    originalPrice: originalPrice, // New Field Added
                    image: imageUrl,
                    affiliateLink: affiliateLink,
                    timestamp: serverTimestamp()
                });
                alert('✅ Product Uploaded Successfully!');
                uploadBtn.textContent = '🚀 Upload Product';
            }

            adminProductForm.reset(); // ফর্ম ফাঁকা করে দেওয়া
            
        } catch (error) {
            console.error("Error saving product: ", error);
            alert('❌ Error processing request.');
            uploadBtn.textContent = editingProductId ? '💾 Update Product' : '🚀 Upload Product';
        } finally {
            uploadBtn.disabled = false;
        }
    });
}

// ২. অ্যাডমিন প্যানেলে প্রোডাক্টের লিস্ট দেখানোর লজিক
if (adminProductList) {
    const productsQuery = query(collection(db, "products"), orderBy("timestamp", "desc"));
    
    onSnapshot(productsQuery, (snapshot) => {
        adminProductList.innerHTML = ''; 

        if (snapshot.empty) {
            adminProductList.innerHTML = '<tr><td colspan="3" style="text-align:center;">No products found.</td></tr>';
            return;
        }

        snapshot.forEach((docSnap) => {
            const product = docSnap.data();
            const productId = docSnap.id;
            
            // ডাটাগুলোকে স্ট্রিং হিসেবে বাটনে পাঠানোর জন্য রেডি করা
            const safeTitle = product.title.replace(/'/g, "\\'");
            const safeImage = product.image.replace(/'/g, "\\'");
            const safeLink = product.affiliateLink.replace(/'/g, "\\'");
            const safeOrigPrice = product.originalPrice ? product.originalPrice : product.price;

            adminProductList.innerHTML += `
                <tr>
                    <td><img src="${product.image}" alt="Img"></td>
                    <td>
                        <strong>${product.title}</strong><br>
                        <span style="color:var(--primary-color);">₹${product.price}</span><br>
                        <small class="text-muted">${product.category}</small>
                    </td>
                    <td>
                        <button class="action-btn edit-btn" onclick="editAdminProduct('${productId}', '${safeTitle}', '${product.category}', ${product.price}, ${safeOrigPrice}, '${safeImage}', '${safeLink}')">✏️ Edit</button>
                        <button class="action-btn delete-btn" onclick="deleteAdminProduct('${productId}')">🗑️ Delete</button>
                    </td>
                </tr>
            `;
        });
    });
}

// ৩. ডিলিট করার গ্লোবাল ফাংশন
window.deleteAdminProduct = async function(id) {
    if(confirm("⚠️ Are you sure you want to delete this product? This cannot be undone!")) {
        try {
            await deleteDoc(doc(db, "products", id));
            alert("🗑️ Product deleted successfully!");
        } catch(error) {
            console.error("Error deleting:", error);
            alert("❌ Failed to delete product.");
        }
    }
};

// ৪. এডিট বাটনে ক্লিক করলে ফর্ম ফিলআপ করার গ্লোবাল ফাংশন (Updated to include Original Price)
window.editAdminProduct = function(id, title, category, price, originalPrice, image, link) {
    document.getElementById('pTitle').value = title;
    document.getElementById('pCategory').value = category;
    document.getElementById('pPrice').value = price;
    document.getElementById('pOriginalPrice').value = originalPrice; // New Field Added
    document.getElementById('pImage').value = image;
    document.getElementById('pAffiliateLink').value = link;

    editingProductId = id; // আইডি সেভ করে রাখা
    
    const formTitle = document.getElementById('formTitle');
    if (formTitle) formTitle.innerHTML = '✏️ Edit Product';
    document.getElementById('uploadBtn').textContent = '💾 Update Product';
    window.scrollTo(0, 0); // ফর্মের কাছে স্ক্রল করে ওপরে নিয়ে যাওয়া
};

// ==========================================
// 12. Load Products from Firestore to Homepage
// ==========================================
const featuredProductsGrid = document.getElementById('featuredProducts');

if (featuredProductsGrid) {
    // ডাটাবেস থেকে প্রোডাক্টগুলো আনার কোয়ারি (সবচেয়ে নতুনটা আগে দেখাবে)
    const productsQuery = query(collection(db, "products"), orderBy("timestamp", "desc"));

    // onSnapshot ব্যবহার করলে ডাটাবেসে প্রোডাক্ট আপলোড করার সাথে সাথে পেজ রিলোড ছাড়াই হোমপেজে চলে আসবে!
    onSnapshot(productsQuery, (snapshot) => {
        featuredProductsGrid.innerHTML = ''; // 'Loading' লেখাটা মুছে ফেলা

        if (snapshot.empty) {
            featuredProductsGrid.innerHTML = '<p style="text-align:center; grid-column: 1 / -1;">No products found. Add some from the Admin Panel!</p>';
            return;
        }

        // ডাটাবেস থেকে পাওয়া প্রতিটি প্রোডাক্টের জন্য একটি করে কার্ড তৈরি করা
        snapshot.forEach((doc) => {
            const product = doc.data();
            
            // Discount Calculation (ডিসকাউন্ট বের করার হিসাব)
            let priceDisplayHtml = `<span class="current-price">₹${product.price}</span>`;
            
            if (product.originalPrice && product.originalPrice > product.price) {
                const discountPercent = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);
                priceDisplayHtml = `
                    <span class="current-price">₹${product.price}</span>
                    <del style="color: #999; margin-left: 8px; font-size: 0.9em;">₹${product.originalPrice}</del>
                    <span style="color: #e74c3c; font-size: 0.85em; font-weight: bold; margin-left: 8px; background: #ffebee; padding: 2px 5px; border-radius: 4px;">(${discountPercent}% OFF)</span>
                `;
            }
            
            // HTML কার্ড তৈরি
            featuredProductsGrid.innerHTML += `
                <div class="product-card">
                    <div class="product-image">
                        <img src="${product.image}" alt="${product.title}">
                    </div>
                    <div class="product-info">
                        <span class="category">${product.category}</span>
                        <h3 class="product-title">${product.title}</h3>
                        
                        <div class="price-box">
                            ${priceDisplayHtml}
                        </div>
                        
                        <!-- Affiliate Button -->
                        <a href="${product.affiliateLink}" target="_blank" rel="noopener noreferrer" class="affiliate-btn">
                            🛍️ Buy Now
                        </a>
                        
                        <!-- WhatsApp Backup for Cashback -->
                        <div style="margin-top: 10px; font-size: 0.85rem; text-align: center;">
                            <span style="color: gray;">Want extra Cashback? </span>
                            <a href="https://whatsapp.com/channel/আপনার_চ্যানেলের_লিংক" target="_blank" style="color: #25D366; font-weight: bold; text-decoration: none;">
                                💬 Join WhatsApp
                            </a>
                        </div>
                    </div>
                </div>
            `;
        });
    });
}